## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 2.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 3.50.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault_secret.secret](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_mssql_database.database_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database) | resource |
| [azurerm_mssql_database.database_secondary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_database) | resource |
| [azurerm_mssql_failover_group.fog](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/mssql_failover_group) | resource |
| [azurerm_key_vault.vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/key_vault) | data source |
| [azurerm_mssql_elasticpool.elasticpool_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/mssql_elasticpool) | data source |
| [azurerm_mssql_elasticpool.elasticpool_secondary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/mssql_elasticpool) | data source |
| [azurerm_mssql_server.server_primary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/mssql_server) | data source |
| [azurerm_mssql_server.server_secondary](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/mssql_server) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_database"></a> [database](#input\_database) | n/a | <pre>object(<br>    {<br>      fail_over_group = string<br>      name            = string<br>      sku_name        = string<br>    }<br>  )</pre> | n/a | yes |
| <a name="input_key_vault_name"></a> [key\_vault\_name](#input\_key\_vault\_name) | Key Vault name | `string` | n/a | yes |
| <a name="input_key_vault_resource_group_name"></a> [key\_vault\_resource\_group\_name](#input\_key\_vault\_resource\_group\_name) | Key Vault Resource Group | `string` | n/a | yes |
| <a name="input_sql_server_administrator_login_password"></a> [sql\_server\_administrator\_login\_password](#input\_sql\_server\_administrator\_login\_password) | Administrator Password | `string` | n/a | yes |
| <a name="input_sql_servers"></a> [sql\_servers](#input\_sql\_servers) | n/a | <pre>object(<br>    {<br>      primary = object({<br>        name                = string<br>        resource_group_name = string<br>        elasticpool_name    = string<br>      })<br>      secondary = object({<br>        name                = string<br>        resource_group_name = string<br>        elasticpool_name    = string<br>      })<br>    }<br>  )</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_database_primary"></a> [database\_primary](#output\_database\_primary) | MS SQL Database (Primary) |
| <a name="output_database_secondary"></a> [database\_secondary](#output\_database\_secondary) | MS SQL Database (Secondary) |
