IF EXISTS(SELECT * FROM sys.sql_logins WHERE name = '$(DbLogin)')
BEGIN
  DROP LOGIN [$(DbLogin)]
END
GO

IF NOT EXISTS (SELECT * FROM sys.sql_logins WHERE name = '$(DbLogin)')
BEGIN
  CREATE LOGIN [$(DbLogin)] WITH PASSWORD='$(DbPassword)', SID = $(SID);
END
GO
