# Info

## Create

    go mod init dev.azure.com/americanhomes4rent/iac-terraform/iac-platform/sql_db
    go mod tidy

## Run

    go test -v -count=1 -timeout 30m module_test.go -tfvars="./test/module.tfvars" -subscriptionID=${ARM_SUBSCRIPTION_ID}
