package test

import (
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/logger"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

var tfVarsFilePath string
var subscriptionID string

// createProviderFile
// Create file provider.tf inside module directory only for testing purpose
func createProviderFile(path string) {
	file, err := os.Create(path)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()

	// Write initial content to the file
	content := "provider \"azurerm\" {\n  features {}\n}\n"
	_, err = io.WriteString(file, content)
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("File created successfully.")
}

// createTerraformBackendFile
// Create file backend.tf inside module directory only for testing purpose
func createTerraformBackendFile(path string) {
	file, err := os.Create(path)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()

	// Write initial content to the file
	content := "terraform {\n  backend \"local\" {}\n}"
	_, err = io.WriteString(file, content)
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("File created successfully.")
}

// TestMain
func TestMain(m *testing.M) {

	// Arguments definition
	flag.StringVar(&tfVarsFilePath, "tfvars", "", "Path to Terraform variables file")
	flag.StringVar(&subscriptionID, "subscriptionID", "", "Subscription ID")
	flag.Parse()

	createProviderFile("../provider.tf")
	createProviderFile("../../Server/provider.tf")
	createProviderFile("../../../KeyVault/provider.tf")

	createTerraformBackendFile("../../Server/backend.tf")

	os.Exit(m.Run())
}

// TestTerraformBasicExample
func TestModuleDb(t *testing.T) {
	// t.Parallel()

	//////////////////////////////////////////////////////////////// KeyVault

	// Terraform options object
	tfOptsKV := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../../KeyVault/",
		Vars: map[string]interface{}{
			"key_vault_name":      terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "key_vault_name"),
			"resource_group_name": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "key_vault_resource_group_name"),
			"TAG_ApplicationName": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_ApplicationName"),
			"TAG_Owner":           terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_Owner"),
		},
	})

	////////////////////////////////// Apply & Eventually Destroy KV

	// Destroy at the end
	defer terraform.Destroy(t, tfOptsKV)

	// Apply
	terraform.InitAndApply(t, tfOptsKV)

	// Output
	vault_uri := terraform.Output(t, tfOptsKV, "vault_uri")
	id := terraform.Output(t, tfOptsKV, "id")
	kv_name := terraform.Output(t, tfOptsKV, "name")
	logger.Log(t, vault_uri)
	logger.Log(t, id)
	logger.Log(t, kv_name)

	//////////////////////////////////////////////////////////////// SqlServer 1

	// Terraform options object
	tfOptsSqlServer1 := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../Server/",
		Vars: map[string]interface{}{
			"resource_group_name":                     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "resource_group_name"),
			"location":                                terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_location1"),
			"sql_server_name":                         terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_name1"),
			"sql_server_version":                      terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_version"),
			"sql_server_administrator_login":          terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_administrator_login"),
			"sql_server_administrator_login_password": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_administrator_login_password"),
			"sql_minimum_tls_version":                 terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_minimum_tls_version"),
			"identity":                                terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "identity"),
			"elasticpool_max_size_gb":                 terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_max_size_gb"),
			"elasticpool_name":                        terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_name1"),
			"elasticpool_sku": map[string]interface{}{
				"name":     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_name"),
				"tier":     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_tier"),
				"capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_capacity"),
			},
			"elasticpool_per_database_settings": map[string]interface{}{
				"min_capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_per_database_settings_min_capacity"),
				"max_capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_per_database_settings_max_capacity"),
			},
			"TAG_ApplicationName": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_ApplicationName"),
			"TAG_Owner":           terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_Owner"),
		},
		BackendConfig: map[string]interface{}{
			"path": "./server_name1.tfstate",
		},
	})
	tfOptsSqlServer1.Reconfigure = true

	////////////////////////////////// Apply & Eventually Destroy

	// Destroy at the end
	defer terraform.Destroy(t, tfOptsSqlServer1)

	// Apply
	terraform.InitAndApply(t, tfOptsSqlServer1)

	// Output
	server_id := terraform.Output(t, tfOptsSqlServer1, "server_id")
	server_fully_qualified_domain_name := terraform.Output(t, tfOptsSqlServer1, "server_fully_qualified_domain_name")
	name1 := terraform.Output(t, tfOptsSqlServer1, "name")
	elasticpool_name1 := terraform.Output(t, tfOptsSqlServer1, "elasticpool_name")

	logger.Log(t, server_id)
	logger.Log(t, server_fully_qualified_domain_name)
	logger.Log(t, name1)
	logger.Log(t, elasticpool_name1)

	//////////////////////////////////////////////////////////////// SqlServer 2

	// Terraform options object
	tfOptsSqlServer2 := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../../Server/",
		Vars: map[string]interface{}{
			"resource_group_name":                     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "resource_group_name"),
			"location":                                terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_location2"),
			"sql_server_name":                         terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_name2"),
			"sql_server_version":                      terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_version"),
			"sql_server_administrator_login":          terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_administrator_login"),
			"sql_server_administrator_login_password": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_administrator_login_password"),
			"sql_minimum_tls_version":                 terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_minimum_tls_version"),
			"identity":                                terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "identity"),
			"elasticpool_max_size_gb":                 terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_max_size_gb"),
			"elasticpool_name":                        terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_name2"),
			"elasticpool_sku": map[string]interface{}{
				"name":     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_name"),
				"tier":     terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_tier"),
				"capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_sku_capacity"),
			},
			"elasticpool_per_database_settings": map[string]interface{}{
				"min_capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_per_database_settings_min_capacity"),
				"max_capacity": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "elasticpool_per_database_settings_max_capacity"),
			},
			"TAG_ApplicationName": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_ApplicationName"),
			"TAG_Owner":           terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "TAG_Owner"),
		},
		BackendConfig: map[string]interface{}{
			"path": "./server_name2.tfstate",
		},
	})
	tfOptsSqlServer2.Reconfigure = true

	////////////////////////////////// Apply & Eventually Destroy

	// Destroy at the end
	defer terraform.Destroy(t, tfOptsSqlServer2)

	// Apply
	terraform.InitAndApply(t, tfOptsSqlServer2)

	// Output
	server_id2 := terraform.Output(t, tfOptsSqlServer2, "server_id")
	server_fully_qualified_domain_name2 := terraform.Output(t, tfOptsSqlServer2, "server_fully_qualified_domain_name")
	name2 := terraform.Output(t, tfOptsSqlServer2, "name")
	elasticpool_name2 := terraform.Output(t, tfOptsSqlServer2, "elasticpool_name")

	logger.Log(t, server_id2)
	logger.Log(t, server_fully_qualified_domain_name2)
	logger.Log(t, name2)
	logger.Log(t, elasticpool_name2)

	//////////////////////////////////////////////////////////////// Sql Db

	// Terraform options object
	tfOptsDb := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../",
		VarFiles:     []string{tfVarsFilePath},
		Vars: map[string]interface{}{
			"sql_servers": map[string]interface{}{
				"primary": map[string]interface{}{
					"name":                name1,
					"resource_group_name": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "resource_group_name"),
					"elasticpool_name":    elasticpool_name1,
				},
				"secondary": map[string]interface{}{
					"name":                name2,
					"resource_group_name": terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "resource_group_name"),
					"elasticpool_name":    elasticpool_name2,
				},
			},
			"key_vault_name": kv_name, // for dependency
		},
	})

	////////////////////////////////// Apply & Eventually Destroy

	// Destroy at the end
	defer terraform.Destroy(t, tfOptsDb)

	// Apply
	terraform.InitAndApply(t, tfOptsDb)

	////////////////////////////////// Tests

	// // Get values from tfvars file
	database := terraform.GetVariableAsMapFromVarFile(t, filepath.Base(tfVarsFilePath), "database")
	resource_group_name := terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "resource_group_name")
	location1 := terraform.GetVariableAsStringFromVarFile(t, filepath.Base(tfVarsFilePath), "sql_server_location1")

	// Get the SQL Server Object
	db, err := azure.GetSQLDatabaseE(t, subscriptionID, resource_group_name, name1, database["name"])

	// Assertions
	assert.NoError(t, err)
	assert.Equal(t, location1, fmt.Sprintf("%v", *db.Location))
	assert.Equal(t, database["name"], fmt.Sprintf("%v", *db.Name))
	assert.Equal(t, elasticpool_name1, fmt.Sprintf("%v", *db.ElasticPoolName))
}
