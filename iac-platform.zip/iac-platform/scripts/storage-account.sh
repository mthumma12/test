#!/bin/bash

#Use az login to login into the portal using the command below
# az login
#Browser window will be open to login, proceed to login
#Use the command below to set the subscription to create the resources in using the command below:
#az account set --subscription "subscription-id"
#Open Terminal, change directory to where the script is store and run the script using the command below:
#./storage-account.sh
#Enter name for resource group when requested
#Enter location for resource group to reside
#Enter name for storage account name

#Create Resource group for storage
read -p 'Enter a name for the resource group for West: ' resource_group_name_west 
read -p 'Enter the location to create resource group in: ' location_west 
az group create \
  --name ${resource_group_name_west} \
  --location ${location_west}

#Create storage account within the resource group
read -p 'Enter a name for the storage account for West: ' storage_account_name_West
az storage account create \
  --name ${storage_account_name_West} \
  --resource-group ${resource_group_name_west} \
  --location ${location_west} \
  --sku Standard_RAGRS \
  --kind StorageV2

#Create Container within storage account
read -p 'Enter a name for the container for West: ' container_name_west
az storage container create -n ${container_name_west} --account-name ${storage_account_name_West}


#East

read -p 'Enter a name for the resource group for East: ' resource_group_name_east
read -p 'Enter the location to create resource group in: ' location_east 
az group create \
  --name ${resource_group_name_east} \
  --location ${location_west}

#Create storage account within the resource group
read -p 'Enter a name for the storage account for East: ' storage_account_name_east
az storage account create \
  --name ${storage_account_name_east} \
  --resource-group ${resource_group_name_east} \
  --location ${location_east} \
  --sku Standard_RAGRS \
  --kind StorageV2

#Create Container within storage account
read -p 'Enter a name for the container for EAST: ' container_name_east
az storage container create -n ${container_name_east} --account-name ${storage_account_name_east}

# AZE-TRN-RG-STATEFILE
# AZW-TRN-RG-STATEFILE


# azetrnstrgstatefile
# azwtrnstrgstatefile

# azetrncntrstatefile
# azwtrncntrstatefile

